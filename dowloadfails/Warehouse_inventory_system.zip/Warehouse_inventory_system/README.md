# Warehouse inventory system

## Timurs Kvačovs | Ksenija Lakotko
##         DP2-4 audzēkņi

Sistēmu programmēšanas projekta uzdevums.

Mūsu projekta galvenā funkcija ir noliktavas uzraudzība - preču pievienošana un rediģēšana, filtrēšana pēc kategorijas, preču kopējo izmaksu aprēķināšana noliktavā, noliktavas ietilpība un preču bilances attēlošana noliktavā.

### Kā programma darbojas?

1. Atlasiet darbību (piemēram, 1 — Pievienot produktu).
2. Ievadiet nosaukumu, kategoriju, piegādātāju, cenu, daudzumu.
3. Mēs redzam “Pievieno produktu…” ar ielādes animāciju.
4. Ja produkts ir pievienots - “Produkts pievienots veiksmīgi”, pretējā gadījumā “Nepietiek vietas”.
5. Eksportējot un filtrējot, ir arī animācija pirms izpildes.

 
